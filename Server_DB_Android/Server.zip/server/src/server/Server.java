package server;

import java.sql.*;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver"; 
	static final String DB_URL = "jdbc:mysql://localhost:3306/sysprog";
	static final String USERNAME = "root";
	static final String PASSWORD = "autoset";


	public static void main(String[] args) {
		
		ServerSocket serverSocket = null;
		
		String time = null;
        String game = null;
        String option = null;
       
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        
        try
        {
            // Create socket and bind with 8988 port.
            serverSocket = new ServerSocket(8988);
            System.out.println("Server is ready.");
        }
        catch (IOException e)
        {
            e.printStackTrace();
        } // try - catch
        
        while (true)
        {
            try
            {
            	// Server socket wait client until connection is applied.
                System.out.println("Waiting Connect.");     
                Socket socket = serverSocket.accept();
                System.out.println(socket.getInetAddress() + " is connected");
                
                try
                {
                	connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                	statement = connection.createStatement();
                	// Get recently alarm data from Database.
                	resultSet = statement.executeQuery("SELECT * FROM clock ORDER BY time_index DESC limit 1");
                	
                	// Get about socket's output stream.
                	BufferedOutputStream bos = new BufferedOutputStream(socket.getOutputStream());

                	/* send data part */
                	String colon = ":";
                	byte[] send_colon = colon.getBytes();
                	
                	while(resultSet.next())
                	{
                		time = resultSet.getString("set_time");
                		game = resultSet.getString("set_game");
                		option = resultSet.getString("set_option");
                		
                		// If data is not suitable, do not send to client. 
                		if(game.equals("LEVEL1"))
                			game = "1";
                		else if(game.equals("LEVEL2"))
                			game = "2";
                		else if(game.equals("LEVEL3"))
                			game = "3";
                		else
                			continue;
                		
                		if(option.equals("LOW"))
                			option = "1";
                		else if(option.equals("USUAL"))
                			option = "2";
                		else if(option.equals("HIGHLY"))
                			option = "3";
                		else
                			continue;
                		
                		// send time
                		byte[] send_time = time.getBytes();
                		bos.write(send_time);
                		bos.write(send_colon);
                		
                		// send level
                		byte[] send_level = game.getBytes();
                		bos.write(send_level);
                		bos.write(send_colon);
                		
                		// send option
                		byte[] send_option = option.getBytes();
                		bos.write(send_option);
                		bos.write(send_colon);
                		bos.flush();
                	}
                	
                    resultSet.close();
                    statement.close();
                    connection.close();
                
                }
                catch (SQLException sqex)
                {
                	System.out.println("SQLException: " + sqex.getMessage());
                	System.out.println("SQLState: " + sqex.getSQLState());
                } finally {        			
                	try {
        				if(statement != null)
        					statement.close();
        			} catch(SQLException se) {
        				se.printStackTrace();
        			}
        			
        			try {
        				if(connection!=null)
        					connection.close();
        			} catch(SQLException se) {
        				se.printStackTrace();
        			}
                } // finally
               
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            } // try - catch
        } // while
    } // main
} // class