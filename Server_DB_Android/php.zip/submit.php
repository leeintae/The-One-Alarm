<?php
$set_game = $_GET['set_game'];
$set_option = $_GET['set_option'];
$set_time = $_GET['set_time'];

$connect = mysqli_connect("localhost","root","autoset")
or die("fail.."); print"success<br>";

$flag = mysqli_select_db($connect,"sysprog");
if(!$flag) die("[DB selection error]");
else echo "데이터베이스 sysprog가 선택됨 <br>";

$sql = "insert into clock(set_game,set_option,set_time) values ('$set_game','$set_option','$set_time')";
$result = mysqli_query($connect,$sql) or die ("fail..".mysqli_error()); 

if($result)
	echo "OK";
else
	echo "0";
?>
